public enum ButtonState {
    case enabled
    case disabled
    case hidden
}

enum AsyncActionButtonState {
    case enabled
    case disabled
    case spinner
}
