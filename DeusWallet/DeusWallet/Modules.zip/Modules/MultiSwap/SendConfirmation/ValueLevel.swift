enum ValueLevel {
    case regular
    case warning
    case error
}
