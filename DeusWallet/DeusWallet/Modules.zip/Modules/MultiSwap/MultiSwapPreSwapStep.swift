class MultiSwapPreSwapStep: Identifiable {
    var id: String {
        fatalError("Must be implemented in subclass")
    }
}
