import RxRelay
import RxSwift

class NftCollectionService {
    private let disposeBag = DisposeBag()

    init() {}
}

extension NftCollectionService {}
