import Foundation
import CommonCrypto

class BackupCrypto: Codable {
    static var defaultBackup = KdfParams(dklen: 32, n: 16384, p: 4, r: 8, salt: AppConfig.backupSalt)

    let cipher: String
    let cipherParams: CipherParams
    let cipherText: String
    let kdf: String
    let kdfParams: KdfParams
    let mac: String

    enum CodingKeys: String, CodingKey {
        case cipher
        case cipherParams = "cipherparams"
        case cipherText = "ciphertext"
        case kdf
        case kdfParams = "kdfparams"
        case mac
    }

    init(cipher: String, cipherParams: CipherParams, cipherText: String, kdf: String, kdfParams: KdfParams, mac: String) {
        self.cipher = cipher
        self.cipherParams = cipherParams
        self.cipherText = cipherText
        self.kdf = kdf
        self.kdfParams = kdfParams
        self.mac = mac
    }

    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        cipher = try container.decode(String.self, forKey: .cipher)
        cipherParams = try container.decode(CipherParams.self, forKey: .cipherParams)
        cipherText = try container.decode(String.self, forKey: .cipherText)
        kdf = try container.decode(String.self, forKey: .kdf)
        kdfParams = try container.decode(KdfParams.self, forKey: .kdfParams)
        mac = try container.decode(String.self, forKey: .mac)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(cipher, forKey: .cipher)
        try container.encode(cipherParams, forKey: .cipherParams)
        try container.encode(cipherText, forKey: .cipherText)
        try container.encode(kdf, forKey: .kdf)
        try container.encode(kdfParams, forKey: .kdfParams)
        try container.encode(mac, forKey: .mac)
    }
}

extension BackupCrypto {
    func decrypt(passphrase: String) throws -> Data {
        try Self.validate(passphrase: passphrase)
        // Validation data
        guard let data = Data(base64Encoded: cipherText) else {
            throw RestoreCloudModule.RestoreError.invalidBackup
        }

        // validation passphrase
        let isValid = try BackupCryptoHelper.isValid(
            macHex: mac,
            pass: passphrase,
            message: cipherText.hs.data,
            kdf: kdfParams
        )
        guard isValid else {
            throw RestoreCloudModule.RestoreError.invalidPassword
        }

        return try BackupCryptoHelper.AES128(
            operation: .decrypt,
            ivHex: cipherParams.iv,
            pass: passphrase,
            message: data,
            kdf: kdfParams
        )
    }
}

extension BackupCrypto {
    static func validate(passphrase: String) throws {
        // Validation passphrase
        guard !passphrase.isEmpty else {
            throw ValidationError.emptyPassphrase
        }
        guard passphrase.count >= BackupCloudModule.minimumPassphraseLength else {
            throw ValidationError.simplePassword
        }

        let allSatisfy = BackupCloudModule.PassphraseCharacterSet.allCases.allSatisfy { set in set.contains(passphrase) }
        if !allSatisfy {
            throw ValidationError.simplePassword
        }
    }

    static func encrypt(data: Data, passphrase: String, kdf: KdfParams = .defaultBackup) throws -> BackupCrypto {
        let iv = BackupCryptoHelper.generateInitialVector().hs.hex

        let cipherText = try BackupCryptoHelper.AES128(
            operation: .encrypt,
            ivHex: iv,
            pass: passphrase,
            message: data,
            kdf: kdf
        )

        let encodedCipherText = cipherText.base64EncodedString()
        let mac = try BackupCryptoHelper.mac(
            pass: passphrase,
            message: encodedCipherText.hs.data,
            kdf: kdf
        )

        return BackupCrypto(
            cipher: BackupCryptoHelper.defaultCypher,
            cipherParams: CipherParams(iv: iv),
            cipherText: encodedCipherText,
            kdf: BackupCryptoHelper.defaultKdf,
            kdfParams: kdf,
            mac: mac.hs.hex
        )
    }
    
    static func encryptCBC(data: Data, passphrase: String) -> Data? {
        let salt = Data((0..<BackupCryptoHelper.PBKDF2_SALT_LENGTH).map { _ in UInt8.random(in: 0...255) })
        guard let key = BackupCryptoHelper.keyFromPasswordAndSalt(password: passphrase, salt: salt) else {
            return nil
        }

        let iv = Data((0..<BackupCryptoHelper.AES256_IV_LENGTH).map { _ in UInt8.random(in: 0...255) })
        let cryptLength = data.count + kCCBlockSizeAES128
        var cryptData = Data(count: cryptLength)

        var numBytesEncrypted: Int = 0

        let status = cryptData.withUnsafeMutableBytes { cryptBytes in
            data.withUnsafeBytes { dataBytes in
                iv.withUnsafeBytes { ivBytes in
                    key.withUnsafeBytes { keyBytes in
                        CCCrypt(
                            CCOperation(kCCEncrypt),
                            CCAlgorithm(kCCAlgorithmAES),
                            CCOptions(kCCOptionPKCS7Padding),
                            keyBytes.bindMemory(to: UInt8.self).baseAddress,
                            key.count,
                            ivBytes.bindMemory(to: UInt8.self).baseAddress,
                            dataBytes.bindMemory(to: UInt8.self).baseAddress,
                            data.count,
                            cryptBytes.bindMemory(to: UInt8.self).baseAddress,
                            cryptLength,
                            &numBytesEncrypted
                        )
                    }
                }
            }
        }

        guard status == kCCSuccess else {
            return nil
        }

        cryptData.removeSubrange(numBytesEncrypted..<cryptData.count)
        return salt + iv + cryptData
    }
    
}

extension BackupCrypto {
    enum ValidationError: Error {
        case emptyPassphrase
        case simplePassword
    }
}
