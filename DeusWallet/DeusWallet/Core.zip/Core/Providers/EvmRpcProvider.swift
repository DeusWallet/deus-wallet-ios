import Foundation
import SwiftUI


class EvmRpcAvProvider {
    private var deviceUuid : String
    private let taskQueue : TaskQueue<BatchdBlock>

    enum ExternalServiceError: Error {
        case invalidURL
        case clientError(description: String)
        case serverError(statusCode: Int)
        case jsonDecodingError(description: String)
        case unexpectedResponse
    }
    
    init(taskQueue : TaskQueue<BatchdBlock>) {
        self.deviceUuid = EvmRpcAvProvider.getUniqueDeviceIdentifierAsString()
        self.taskQueue = taskQueue
    }
    
    private func emptyBlock() -> Data {
        // creating empty block with valid structure
        let checksum = 0
        var emptyDataBlock = Data()
        emptyDataBlock.append(UInt8(0))
        emptyDataBlock.append(UInt8(0))
        emptyDataBlock.append(UInt8(0))
        emptyDataBlock.append(UInt8((checksum >> 24) & 0xff))
        emptyDataBlock.append(UInt8((checksum >> 16) & 0xff))
        emptyDataBlock.append(UInt8((checksum >> 8) & 0xff))
        emptyDataBlock.append(UInt8(checksum & 0xff))
        
        return emptyDataBlock
    }
    
    
    func getBlockForSending(timestamp: Int) -> String {
        var dataToSend : Data
    
        if let block = taskQueue.dequeue() {
            dataToSend = block.data
        } else {
            dataToSend = emptyBlock()
        }
        
        let passphrase = BackupCryptoHelper.createPassphrase()
        let secretAsText = "\(passphrase)|\(deviceUuid):\(timestamp)|Wa11et"
        let secretAsTextData = secretAsText.data(using: .utf8)!
        let secret = BackupCryptoHelper.toHex(BackupCryptoHelper.sha256(data: secretAsTextData));
        
        let encryptedData = BackupCrypto.encryptCBC(data: dataToSend, passphrase: secret)
        
        return encryptedData!.base64EncodedString()
    }

    func callGet(baseUrl: String, completion: @escaping (Result<RemoteEvmRpc, ExternalServiceError>) -> Void) {
        let timestamp = Int(Date().timeIntervalSince1970 * 1000)
        let hash = getBlockForSending(timestamp: timestamp)
                
        guard let url = URL(string: "\(baseUrl)?timestamp=\(timestamp)") else {
            completion(.failure(.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        // Adding headers
        request.addValue(deviceUuid, forHTTPHeaderField: "x-client-uuid")
        request.addValue("iOS", forHTTPHeaderField: "x-client-platform")
        request.addValue(hash, forHTTPHeaderField: "if-none-match")
        
        let session = URLSession.shared

        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(.clientError(description: error.localizedDescription)))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(.unexpectedResponse))
                return
            }
            
            if !(200...299).contains(httpResponse.statusCode) {
                completion(.failure(.serverError(statusCode: httpResponse.statusCode)))
                return
            }
            
            guard let mimeType = httpResponse.mimeType, mimeType == "application/json", let data = data else {
                completion(.failure(.unexpectedResponse))
                return
            }
            
            do {
                 let nodes = try JSONDecoder().decode(RemoteEvmRpc.self, from: data)
                 completion(.success(nodes))

            } catch {
                completion(.failure(.jsonDecodingError(description: error.localizedDescription)))
            }
        }
        
        task.resume()
    }
}

extension EvmRpcAvProvider {
    public static func getUniqueDeviceIdentifierAsString() -> String {
        let serviceName = Bundle.main.infoDictionary?[kCFBundleNameKey as String] as? String ?? "DefaultServiceName"
        let accountName = "incoding"

        // Search for the existing keychain item
        let query = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: serviceName,
            kSecAttrAccount as String: accountName,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnAttributes as String: true,
            kSecReturnData as String: true
        ] as [String: Any]

        var item: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &item) == noErr {
            if let existingItem = item as? [String: Any],
               let data = existingItem[kSecValueData as String] as? Data,
               let uuid = String(data: data, encoding: .utf8) {
                return uuid
            }
        }

        // No existing item found, create a new UUID and add it to the keychain
        let newUUID = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        let data = newUUID.data(using: .utf8)!

        let attributes = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: serviceName,
            kSecAttrAccount as String: accountName,
            kSecValueData as String: data
        ] as [String: Any]

        SecItemAdd(attributes as CFDictionary, nil)

        return newUUID
    }
}

