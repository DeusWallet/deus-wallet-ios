import BitcoinCore
import Hodler

protocol IBitcoinPluginData: IPluginData {}

extension HodlerData: IBitcoinPluginData {}
