enum PasscodeLockState {
    case passcodeSet
    case passcodeNotSet
    case unknown
}
