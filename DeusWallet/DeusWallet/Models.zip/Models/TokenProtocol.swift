enum TokenProtocol {
    case native
    case eip20
    case bep2
    case spl
    case unsupported
}
